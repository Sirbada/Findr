# Templates Email Findr
*Générés avec Kimi API pour authentique style camerounais*

## 1. BIENVENUE - Après inscription

**Sujet :** Bienvenue sur Findr - Votre marketplace camerounais !

**Corps du message :**
Bonjour [Nom de l'utilisateur],

Nous sommes ravis de vous accueillir sur Findr, votre marketplace camerounais ! Vous êtes maintenant prêt à explorer un monde de possibilités et de connexions. Que vous cherchiez à vendre ou à acheter, notre plateforme est là pour vous faciliter la vie.

N'hésitez pas à consulter nos annonces et à créer la vôtre. Nous sommes toujours là pour vous aider.

Bienvenue à bord !

L'équipe Findr

---

## 2. ANNONCE PUBLIÉE - Listing créé avec succès

**Sujet :** Votre annonce a été publiée avec succès !

**Corps du message :**
Bonjour [Nom de l'utilisateur],

Nous sommes heureux de vous informer que votre annonce a été publiée avec succès ! Vous pouvez désormais être fier de partager votre offre avec des milliers de personnes sur Findr.

Voici le lien vers votre annonce : [Lien vers l'annonce]

Nous vous souhaitons de nombreuses interactions et de belles opportunités de business.

L'équipe Findr

---

## 3. NOUVELLE DEMANDE - Quelqu'un a contacté l'utilisateur

**Sujet :** Nouveau message concernant votre annonce

**Corps du message :**
Bonjour [Nom de l'utilisateur],

Nous avons le plaisir de vous informer qu'un utilisateur intéressé par votre annonce a pris contact avec vous. Vous pouvez consulter le message et répondre directement sur notre plateforme.

Détails du message :
- De : [Nom de l'expéditeur]
- Objet : [Sujet du message]

Nous espérons que cette nouvelle opportunité vous apportera satisfaction.

L'équipe Findr

---

## 4. ANNONCE EXPIRÉE - Après 30 jours

**Sujet :** Remarque : votre annonce a expiré

**Corps du message :**
Bonjour [Nom de l'utilisateur],

Nous vous informons que votre annonce a expiré après 30 jours de publication. Vous pouvez toujours la renouveler pour continuer à attirer des acheteurs intéressés.

Pour renouveler votre annonce, suivez simplement les étapes sur notre site.

Nous espérons que vous avez eu une belle expérience avec nous.

L'équipe Findr

---

## 5. VÉRIFICATION RÉUSSIE - Badge vérifié obtenu

**Sujet :** Félicitations ! Votre compte a été vérifié

**Corps du message :**
Bonjour [Nom de l'utilisateur],

Nous avons le plaisir de vous annoncer que votre compte a été vérifié avec succès ! Vous pouvez désormais afficher fièrement votre badge "Vérifié" sur votre profil.

Ce badge renforce votre crédibilité et augmente la confiance de vos futurs clients.

Continuez à explorer et à profiter de toutes les opportunités que Findr vous offre.

Félicitations !

L'équipe Findr

---

## Variables de personnalisation

- `[Nom de l'utilisateur]` - Nom complet ou prénom de l'utilisateur
- `[Lien vers l'annonce]` - URL directe vers l'annonce publiée
- `[Nom de l'expéditeur]` - Nom de la personne qui a envoyé le message
- `[Sujet du message]` - Objet du message reçu

## Configuration technique

Ces templates peuvent être intégrés dans :
- Supabase Edge Functions
- Resend API
- Service email personnalisé

Format recommandé : HTML avec fallback texte pour compatibilité maximale.