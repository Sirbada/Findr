# FAQ Findr
*Questions fréquemment posées*

## Compte et inscription

**Comment créer mon compte ?**
Cliquez sur "S'inscrire", entrez votre nom, téléphone et email. Confirmez par SMS et c'est bon !

**Pourquoi faut-il vérifier mon numéro ?**
Pour éviter les faux comptes et protéger tout le monde. Vous recevez un code SMS à valider.

**Comment obtenir le badge "Vérifié" ?**
Envoyez-nous une photo de votre CNI ou passeport. Vérification sous 24h.

**J'ai oublié mon mot de passe, que faire ?**
Cliquez "Mot de passe oublié" sur la page de connexion. Vous recevrez un lien par email.

## Publier une annonce

**Comment publier ma première annonce ?**
Connectez-vous → "Publier" → Choisissez catégorie → Ajoutez photos et description → Publiez !

**Mes photos ne s'uploadent pas, pourquoi ?**
Vérifiez que vos photos font moins de 5 Mo chacune. Format accepté : JPG, PNG.

**Combien de photos puis-je mettre ?**
Maximum 8 photos par annonce. La première sera la photo principale.

**Mon annonce n'apparaît pas, normal ?**
Les nouvelles annonces sont vérifiées sous 2h pendant les heures ouvrables.

## Sécurité et paiements

**Le site est-il sécurisé pour acheter ?**
Findr facilite le contact, mais les transactions se font directement entre vous. Rencontrez-vous dans un lieu public.

**Y a-t-il des frais pour utiliser Findr ?**
Non, Findr est entièrement gratuit pour acheter et vendre.

**Comment éviter les arnaques ?**
• Rencontrez en personne avant de payer
• Méfiez-vous des prix trop bas
• Payez après avoir vu l'objet
• Utilisez les messages Findr pour communiquer

**Que faire si quelqu'un me demande de l'argent à l'avance ?**
N'envoyez jamais d'argent avant d'avoir vu l'objet. Signalez immédiatement ce type de message.

## Communication et contact

**Comment contacter un vendeur ?**
Cliquez "Contacter" sur son annonce. Vous pouvez envoyer un message ou l'appeler directement.

**Le vendeur ne répond pas, que faire ?**
Essayez d'appeler ou attendez 24h. Vous pouvez aussi chercher un autre vendeur.

**Puis-je négocier le prix ?**
Bien sûr ! La négociation fait partie de la culture camerounaise. Soyez respectueux.

**Mes messages n'arrivent pas, pourquoi ?**
Vérifiez votre connexion internet. Les messages peuvent être retardés en cas de réseau faible.

## Livraison et rencontre

**Comment se fait la livraison ?**
Findr ne gère pas la livraison. Organisez-vous directement avec le vendeur (rencontre, transport, etc.).

**Où rencontrer en sécurité ?**
Lieux publics recommandés : centres commerciaux, stations-service, parkings fréquentés.

**Puis-je faire livrer chez moi ?**
C'est entre vous et le vendeur. Pour les gros objets, c'est souvent nécessaire.

## Gestion des annonces

**Comment modifier mon annonce ?**
Allez dans "Mes annonces" → Cliquez sur l'annonce → "Modifier".

**Comment supprimer mon annonce ?**
Dans "Mes annonces" → Cliquez sur l'annonce → "Supprimer" → Confirmez.

**Pourquoi mon annonce a été supprimée ?**
Possible raison : contenu inapproprié, fausses infos, ou signalement d'autres utilisateurs.

**Combien de temps reste une annonce en ligne ?**
30 jours. Vous recevez un rappel pour renouveler avant expiration.

## Problèmes techniques

**Le site est lent, c'est normal ?**
Cela dépend de votre connexion. Essayez de fermer d'autres onglets ou recharger la page.

**L'app existe-t-elle sur mobile ?**
Pas encore, mais le site web fonctionne parfaitement sur mobile.

---

**Une autre question ?**
Contactez-nous : support@findr.cm ou +237 6XX XXX XXX