# POLITIQUE DE CONFIDENTIALITÉ

**Dernière mise à jour : Février 2025**

Le marketplace respecte la confidentialité de vos données personnelles et s'engage à les protéger conformément à la loi camerounaise n°2024/017 sur la protection des données personnelles.

## 1. DONNÉES COLLECTÉES

Nous collectons les données suivantes lors de votre utilisation de la plateforme :

**Données d'identification :**
- Nom, prénoms, numéro de téléphone
- Adresse e-mail et adresse physique
- Informations de profil utilisateur

**Données transactionnelles :**
- Informations de paiement et détails bancaires
- Historique d'achats et de ventes
- Communications avec les vendeurs

**Données techniques :**
- Informations de navigation et d'utilisation
- Adresses IP, type de navigateur, pages visitées
- Données de géolocalisation (avec votre consentement)

## 2. FINALITÉS DU TRAITEMENT

Vos données sont traitées pour les finalités suivantes :

- Gestion de votre compte et des transactions
- Amélioration de l'expérience utilisateur et des services
- Prévention de la fraude et assurance de la sécurité
- Respect des obligations légales et réglementaires
- Communication d'informations pertinentes sur nos services

## 3. PARTAGE DES DONNÉES

Nous pouvons partager vos données avec :

**Partenaires de paiement :** Pour traiter vos transactions de manière sécurisée
**Prestataires techniques :** Pour la maintenance et l'amélioration de la plateforme
**Autorités compétentes :** En cas d'obligation légale ou de demande judiciaire
**Autres utilisateurs :** Informations limitées nécessaires aux transactions (nom, localisation générale)

Aucune donnée n'est vendue à des tiers à des fins commerciales.

## 4. SÉCURITÉ DES DONNÉES

Nous mettons en œuvre des mesures de sécurité appropriées :

- Cryptage des données sensibles (SSL/TLS)
- Accès restreint aux données personnelles
- Surveillance continue des systèmes
- Sauvegardes sécurisées et régulières
- Formation du personnel aux bonnes pratiques

## 5. DROITS DES UTILISATEURS

Conformément à la loi camerounaise, vous disposez des droits suivants :

**Droit d'accès :** Obtenir une copie de vos données personnelles
**Droit de rectification :** Corriger des données inexactes ou incomplètes  
**Droit d'effacement :** Demander la suppression de vos données
**Droit d'opposition :** Vous opposer au traitement pour motifs légitimes
**Droit à la portabilité :** Recevoir vos données dans un format structuré

Pour exercer ces droits, contactez notre DPO aux coordonnées indiquées ci-dessous.

## 6. UTILISATION DES COOKIES

Notre site utilise des cookies pour :

- Assurer le bon fonctionnement de la plateforme
- Mémoriser vos préférences et paramètres
- Analyser le trafic et améliorer nos services
- Personnaliser votre expérience utilisateur

Vous pouvez configurer votre navigateur pour refuser les cookies, mais certaines fonctionnalités pourraient être limitées.

## 7. CONSERVATION DES DONNÉES

Les données sont conservées pendant :

- **Données de compte :** Durée d'activité du compte + 3 ans
- **Données transactionnelles :** 10 ans (obligation légale comptable)
- **Données de navigation :** 13 mois maximum
- **Données de sécurité :** 1 an après résolution des incidents

## 8. CONTACT DPO (DÉLÉGUÉ À LA PROTECTION DES DONNÉES)

Pour toute question concernant vos données personnelles :

**Email :** dpo@plateforme.cm
**Téléphone :** +237 XX XX XX XX
**Adresse :** [Adresse complète], Douala, Cameroun

**Heures de contact :** Lundi-Vendredi, 8h-17h

## 9. MODIFICATIONS

Cette politique peut être mise à jour pour refléter les changements légaux ou opérationnels. Les modifications importantes vous seront notifiées par email ou via un avis sur la plateforme.

## 10. RÉCLAMATIONS

En cas de désaccord concernant le traitement de vos données, vous pouvez :

1. Nous contacter directement via notre DPO
2. Saisir l'autorité camerounaise compétente
3. Introduire un recours devant les tribunaux camerounais

---

**En utilisant notre plateforme, vous acceptez cette politique de confidentialité et le traitement de vos données personnelles dans les conditions décrites.**