# CONDITIONS GÉNÉRALES D'UTILISATION

## 1. OBJET

Les présentes Conditions Générales d'Utilisation (CGU) définissent les modalités et conditions d'accès et d'utilisation de la plateforme. Notre plateforme est un marketplace digital facilitant les transactions commerciales entre utilisateurs au Cameroun. Les CGU sont régies par le droit OHADA et le droit camerounais, notamment le Code des Obligations Commerciales.

## 2. INSCRIPTION

L'inscription implique l'acceptation pleine et entière des présentes CGU. Les utilisateurs doivent fournir des informations véridiques et complètes. La fourniture de faux renseignements entraîne la résiliation immédiate du compte.

## 3. ANNONCES

Les annonces doivent être conformes aux lois camerounaises en vigueur. Les utilisateurs sont responsables du contenu de leurs annonces et garantissent leur exactitude et actualité. Sont interdites les annonces discriminatoires, illicites ou portant sur des biens contrefaits.

## 4. RESPONSABILITÉS

La plateforme ne garantit pas l'exactitude des informations utilisateur et ne peut être tenue responsable des dommages liés à leur utilisation. Les utilisateurs agissent sous leur propre responsabilité lors des transactions.

## 5. PAIEMENTS

Les transactions sont sécurisées via des systèmes de paiement reconnus. La plateforme se réserve le droit de suspendre les comptes en cas de suspicion de fraude ou d'usage abusif du système de paiement.

## 6. PROPRIÉTÉ INTELLECTUELLE

Le contenu est protégé par les lois sur la propriété intellectuelle. Toute reproduction, modification ou distribution du contenu est interdite sans autorisation explicite. Les marques et logos demeurent propriété de leurs titulaires respectifs.

## 7. DONNÉES PERSONNELLES

La plateforme respecte la confidentialité des données personnelles. Les données collectées servent uniquement à gérer et améliorer les services. Les utilisateurs disposent d'un droit d'accès et de rectification de leurs données.

## 8. RÉSILIATION

La plateforme peut résilier un compte pour non-respect des CGU ou tout motif légitime, avec effet immédiat et sans préavis. Les utilisateurs peuvent résilier leur compte à tout moment.

## 9. LITIGES

Tout litige relève de la compétence exclusive du Tribunal de Première Instance de Douala, conformément au droit OHADA et camerounais.

## 10. MODIFICATIONS

Les CGU peuvent être modifiées à tout moment. Les modifications sont publiées sur la plateforme et entrent en vigueur immédiatement. Les utilisateurs sont invités à consulter régulièrement les CGU.

## 11. CONTACT

Pour toute question concernant les CGU, contactez-nous via le formulaire de contact ou par email à : [contact@plateforme.cm]

Les présentes CGU sont acceptées lors de l'inscription et demeurent en vigueur durant toute la durée d'activité du compte.

**Dernière mise à jour :** Février 2025