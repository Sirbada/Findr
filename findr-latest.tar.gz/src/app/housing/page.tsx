import { Metadata } from 'next'
import { HousingPageClient } from './page-client'

export const metadata: Metadata = {
  title: 'Immobilier au Cameroun - Findr',
  description: 'Trouvez votre logement idéal au Cameroun. Appartements, maisons et terrains vérifiés à Douala, Yaoundé et partout au pays. Location et vente sans arnaques.',
  keywords: ['immobilier', 'logement', 'appartement', 'maison', 'terrain', 'location', 'vente', 'Cameroun', 'Douala', 'Yaoundé', 'studio', 'villa'],
  openGraph: {
    title: 'Immobilier au Cameroun - Findr',
    description: 'Trouvez votre logement idéal au Cameroun. Biens immobiliers vérifiés sans arnaques.',
    url: '/housing',
    type: 'website',
    images: [
      {
        url: '/og-housing.jpg',
        width: 1200,
        height: 630,
        alt: 'Immobilier au Cameroun sur Findr',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Immobilier au Cameroun - Findr',
    description: 'Logements vérifiés au Cameroun sans arnaques.',
    images: ['/og-housing.jpg'],
  },
}

export default function HousingPage() {
  return (
    <>
      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebPage",
            "name": "Immobilier au Cameroun",
            "description": "Trouvez votre logement idéal au Cameroun. Appartements, maisons et terrains vérifiés.",
            "url": "https://findr.cm/housing",
            "breadcrumb": {
              "@type": "BreadcrumbList",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Accueil",
                  "item": "https://findr.cm"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Immobilier",
                  "item": "https://findr.cm/housing"
                }
              ]
            },
            "mainEntity": {
              "@type": "RealEstateListing",
              "name": "Biens immobiliers au Cameroun",
              "description": "Découvrez des milliers de biens immobiliers vérifiés au Cameroun",
              "floorArea": {
                "@type": "QuantitativeValue",
                "value": "Varies"
              },
              "address": {
                "@type": "PostalAddress",
                "addressCountry": "CM",
                "addressLocality": "Cameroun"
              }
            }
          }),
        }}
      />
      <HousingPageClient />
    </>
  )
}