import { Header } from '@/components/layout/Header'
import { Footer } from '@/components/layout/Footer'
import { HeroEnhanced } from '@/components/home/HeroEnhanced'
import { CategoriesEnhanced } from '@/components/home/CategoriesEnhanced'
import { HowItWorks } from '@/components/home/HowItWorks'
import { StatsCounter } from '@/components/home/StatsCounter'
import { Testimonials } from '@/components/home/Testimonials'
import { TrustedBy } from '@/components/home/TrustedBy'
import { OnboardingFlow } from '@/components/onboarding/OnboardingFlow'
import { ToastProvider } from '@/components/ui/Toast'

export default function Home() {
  return (
    <ToastProvider>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <HeroEnhanced />
          <CategoriesEnhanced />
          <HowItWorks />
          <StatsCounter />
          <Testimonials />
          <TrustedBy />
        </main>
        <Footer />
        <OnboardingFlow />
      </div>
    </ToastProvider>
  )
}
