'use client'

import { ReactNode } from 'react'
import { TranslationProvider } from '@/lib/i18n/context'
import { DataSaverProvider } from '@/lib/data-saver/context'
import { AuthProvider } from '@/lib/auth/context'
import { InstallBanner } from '@/components/ui/InstallPrompt'
import { AnalyticsProvider } from '@/components/analytics/AnalyticsProvider'
import { PushPermissionRequest } from '@/components/notifications/PushPermissionRequest'

export function Providers({ children }: { children: ReactNode }) {
  return (
    <TranslationProvider>
      <AuthProvider>
        <DataSaverProvider>
          <AnalyticsProvider>
            {children}
            {/* PWA Install Banner - Shows on mobile when not installed */}
            <InstallBanner />
            {/* Push Notification Permission Request */}
            <div className="fixed bottom-4 left-4 right-4 z-50 max-w-md mx-auto">
              <PushPermissionRequest />
            </div>
          </AnalyticsProvider>
        </DataSaverProvider>
      </AuthProvider>
    </TranslationProvider>
  )
}
