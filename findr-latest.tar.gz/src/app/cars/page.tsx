import { Metadata } from 'next'
import { CarsPageClient } from './page-client'

export const metadata: Metadata = {
  title: 'Véhicules au Cameroun - Findr',
  description: 'Achetez ou louez votre véhicule au Cameroun. Voitures, motos et utilitaires vérifiés à Douala, Yaoundé et dans tout le pays. Occasion et neuf.',
  keywords: ['véhicule', 'voiture', 'auto', 'moto', 'utilitaire', 'location', 'achat', 'occasion', 'neuf', 'Cameroun', 'Douala', 'Yaoundé', 'Toyota', 'Mercedes'],
  openGraph: {
    title: 'Véhicules au Cameroun - Findr',
    description: 'Trouvez votre véhicule idéal au Cameroun. Voitures vérifiées sans arnaques.',
    url: '/cars',
    type: 'website',
    images: [
      {
        url: '/og-cars.jpg',
        width: 1200,
        height: 630,
        alt: 'Véhicules au Cameroun sur Findr',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Véhicules au Cameroun - Findr',
    description: 'Véhicules vérifiés au Cameroun.',
    images: ['/og-cars.jpg'],
  },
}

export default function CarsPage() {
  return (
    <>
      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebPage",
            "name": "Véhicules au Cameroun",
            "description": "Achetez ou louez votre véhicule au Cameroun. Voitures, motos et utilitaires vérifiés.",
            "url": "https://findr.cm/cars",
            "breadcrumb": {
              "@type": "BreadcrumbList",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Accueil",
                  "item": "https://findr.cm"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Véhicules",
                  "item": "https://findr.cm/cars"
                }
              ]
            },
            "mainEntity": {
              "@type": "Product",
              "category": "Vehicle",
              "name": "Véhicules au Cameroun",
              "description": "Large sélection de véhicules au Cameroun",
              "offers": {
                "@type": "AggregateOffer",
                "priceCurrency": "XAF",
                "availability": "https://schema.org/InStock"
              }
            }
          }),
        }}
      />
      <CarsPageClient />
    </>
  )
}