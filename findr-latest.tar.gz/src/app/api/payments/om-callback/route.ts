import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

/**
 * Orange Money Payment Callback
 * Called by Orange when payment status changes
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { status, transactionId, orderId, amount, phone, timestamp, signature } = body

    console.log(`[OM Callback] TX: ${transactionId}, Status: ${status}, Amount: ${amount} XAF`)

    if (!transactionId || !status) {
      return NextResponse.json({ error: 'Missing transactionId or status' }, { status: 400 })
    }

    // TODO: Verify signature with OM API secret in production
    // const expectedSignature = hmac(OM_API_SECRET, `${transactionId}${status}${amount}`)
    // if (signature !== expectedSignature) return 403

    const supabase = await createClient()

    // Find transaction
    const { data: transaction, error: txError } = await supabase
      .from('transactions')
      .select('*')
      .eq('payment_reference', transactionId)
      .single()

    if (txError || !transaction) {
      console.error(`[OM Callback] Transaction not found: ${transactionId}`)
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    // Map OM status
    const statusMap: Record<string, string> = {
      'SUCCESSFUL': 'completed',
      'FAILED': 'failed',
      'EXPIRED': 'expired',
      'CANCELLED': 'cancelled',
      'INITIATED': 'pending',
      'PENDING': 'pending',
      'PROCESSING': 'processing',
    }

    const newStatus = statusMap[status] || 'pending'

    // Update transaction
    const { error: updateError } = await supabase
      .from('transactions')
      .update({
        status: newStatus,
        provider_transaction_id: transactionId,
        updated_at: new Date().toISOString(),
        metadata: {
          ...((transaction.metadata as Record<string, unknown>) || {}),
          om_status: status,
          om_phone: phone,
          om_timestamp: timestamp,
          callback_received_at: new Date().toISOString(),
        }
      })
      .eq('id', transaction.id)

    if (updateError) {
      console.error(`[OM Callback] Update failed:`, updateError)
      return NextResponse.json({ error: 'Update failed' }, { status: 500 })
    }

    // If successful, update booking
    if (newStatus === 'completed' && transaction.booking_id) {
      await supabase
        .from('bookings')
        .update({
          payment_status: 'completed',
          status: 'confirmed',
          updated_at: new Date().toISOString(),
        })
        .eq('id', transaction.booking_id)
    }

    console.log(`[OM Callback] Transaction ${transaction.id} updated to ${newStatus}`)
    return NextResponse.json({ success: true })

  } catch (error) {
    console.error('[OM Callback] Error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({ status: 'ok', service: 'findr-om-callback' })
}
