import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

/**
 * MTN MoMo Payment Callback
 * Called by MTN when payment status changes
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { referenceId, status, financialTransactionId, externalId, amount, payer } = body

    console.log(`[MoMo Callback] Ref: ${referenceId}, Status: ${status}, Amount: ${amount?.amount} ${amount?.currency}`)

    if (!referenceId || !status) {
      return NextResponse.json({ error: 'Missing referenceId or status' }, { status: 400 })
    }

    const supabase = await createClient()

    // Find the transaction by reference
    const { data: transaction, error: txError } = await supabase
      .from('transactions')
      .select('*')
      .eq('payment_reference', referenceId)
      .single()

    if (txError || !transaction) {
      console.error(`[MoMo Callback] Transaction not found: ${referenceId}`)
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    // Map MoMo status to our status
    const statusMap: Record<string, string> = {
      'SUCCESSFUL': 'completed',
      'FAILED': 'failed',
      'REJECTED': 'failed',
      'TIMEOUT': 'expired',
      'CANCELLED': 'cancelled',
      'PENDING': 'pending',
      'PROCESSING': 'processing',
    }

    const newStatus = statusMap[status] || 'pending'

    // Update transaction
    const { error: updateError } = await supabase
      .from('transactions')
      .update({
        status: newStatus,
        provider_transaction_id: financialTransactionId || null,
        updated_at: new Date().toISOString(),
        metadata: {
          ...((transaction.metadata as Record<string, unknown>) || {}),
          momo_status: status,
          momo_payer: payer?.partyId,
          callback_received_at: new Date().toISOString(),
        }
      })
      .eq('id', transaction.id)

    if (updateError) {
      console.error(`[MoMo Callback] Update failed:`, updateError)
      return NextResponse.json({ error: 'Update failed' }, { status: 500 })
    }

    // If payment successful, update booking status
    if (newStatus === 'completed' && transaction.booking_id) {
      await supabase
        .from('bookings')
        .update({
          payment_status: 'completed',
          status: 'confirmed',
          updated_at: new Date().toISOString(),
        })
        .eq('id', transaction.booking_id)
    }

    console.log(`[MoMo Callback] Transaction ${transaction.id} updated to ${newStatus}`)
    return NextResponse.json({ success: true })

  } catch (error) {
    console.error('[MoMo Callback] Error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// MTN may also send GET requests for verification
export async function GET() {
  return NextResponse.json({ status: 'ok', service: 'findr-momo-callback' })
}
