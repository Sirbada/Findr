import { Metadata } from 'next'
import { TerrainPageClient } from './page-client'

export const metadata: Metadata = {
  title: 'Terrains au Cameroun - Findr',
  description: 'Achetez votre terrain au Cameroun. Terrains titrés et sécurisés à Douala, Yaoundé et dans tout le pays. Résidentiel, commercial et agricole.',
  keywords: ['terrain', 'foncier', 'parcelle', 'titre foncier', 'vente', 'achat', 'Cameroun', 'Douala', 'Yaoundé', 'résidentiel', 'commercial', 'agricole', 'constructible'],
  openGraph: {
    title: 'Terrains au Cameroun - Findr',
    description: 'Trouvez votre terrain idéal au Cameroun. Terrains titrés et sécurisés.',
    url: '/terrain',
    type: 'website',
    images: [
      {
        url: '/og-terrain.jpg',
        width: 1200,
        height: 630,
        alt: 'Terrains au Cameroun sur Findr',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Terrains au Cameroun - Findr',
    description: 'Terrains titrés au Cameroun.',
    images: ['/og-terrain.jpg'],
  },
}

export default function TerrainPage() {
  return (
    <>
      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebPage",
            "name": "Terrains au Cameroun",
            "description": "Achetez votre terrain au Cameroun. Terrains titrés et sécurisés.",
            "url": "https://findr.cm/terrain",
            "breadcrumb": {
              "@type": "BreadcrumbList",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Accueil",
                  "item": "https://findr.cm"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Terrains",
                  "item": "https://findr.cm/terrain"
                }
              ]
            },
            "mainEntity": {
              "@type": "RealEstateListing",
              "name": "Terrains au Cameroun",
              "description": "Large sélection de terrains au Cameroun",
              "address": {
                "@type": "PostalAddress",
                "addressCountry": "CM",
                "addressLocality": "Cameroun"
              }
            }
          }),
        }}
      />
      <TerrainPageClient />
    </>
  )
}